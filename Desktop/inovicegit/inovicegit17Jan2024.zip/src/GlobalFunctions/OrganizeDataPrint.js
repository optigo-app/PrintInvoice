import { CapitalizeWords, otherAmountDetail, taxGenrator } from "../GlobalFunctions";
import { numberToWords } from "number-to-words";

export const OrganizeDataPrint = (header, json1, json2) => {
 
  let resultArray = [];
  let jobnodup = [];
  let maintotal = {
    diamonds: {
      Wt: 0,
      Pcs: 0,
      Rate: 0,
      Amount: 0,
      SettingAmount: 0
    },
    colorstone: {
      Wt: 0,
      Pcs: 0,
      Rate: 0,
      Amount: 0,
      SettingAmount: 0
    },
    metal: {
      Wt: 0,
      Pcs: 0,
      Rate: 0,
      Amount: 0,
      FineWt: 0,
    },
    finding: {
      Wt: 0,
      Pcs: 0,
      Rate: 0,
      Amount: 0,
    },
    misc: {
      Wt: 0,
      Pcs: 0,
      Rate: 0,
      Amount: 0,
    },
    stone_misc: {
      Wt: 0,
      Pcs: 0,
      Rate: 0,
      Amount: 0,
    },
    total_labour: {
      labour_rate: 0,
      labour_amount: 0,
    },
    total_diamond_colorstone_misc_amount: 0,
    total_other: 0,
    grosswt: 0,
    netwt: 0,
    netwtWithLossWt: 0,
    convertednetwt: 0,
    MetalAmount: 0,
    lossWt: 0,
    total_Wastage: 0,
    total_FineWt: 0,
    total_amount: 0,
    total_unitcost: 0,
    total_discount_amount: 0,
    total_purenetwt: 0,
    total_Quantity: 0,
    total_Making_Amount: 0,
    total_discount: 0,
    total_diamondHandling: 0,
    total_csamount:0,
    total_Making_Amount_Other_Charges:0,
    total_fineWtByMetalWtCalculation:0,
    totalMiscAmount: 0,
    total_otherChargesMiscHallStamp:0, 
    total_TotalCsSetcost : 0,
    total_TotalDiaSetcost: 0
  };

  //json1 array
  json1?.length > 0 &&
    json1?.forEach((j1) => {
      let diamond_colorstone_misc = [];
      let diamondList = [];
      let colorstoneList = [];
      let metalList = [];
      let findingList = [];
      let miscList = [];
      let stone_miscList = [];
      let blankArrDiamond = [];
      let blankArrColorstone = [];
      let blankArrMisc = [];
      let blankArrMetal = [];
      let blankArrFinding = [];
      let blankArrstone_misc = [];
      let diamondSettingGroup = [];
      let colorstoneSettingGroup = [];
      let diamondMetalPurityWise = [];
      let colorstoneMetalPurityWise = [];
      let diamondWtMetalPurityWise = 0;
      let colorstoneWtMetalPurityWise = 0;
      let jobwise_totals = {
        diamonds: {
          Wt: 0,
          Pcs: 0,
          Rate: 0,
          Amount: 0,
          SettingAmount: 0,
          FineWt: 0,
          length: 0,
        },
        colorstone: {
          Wt: 0,
          Pcs: 0,
          Rate: 0,
          Amount: 0,
          SettingAmount: 0,
          FineWt: 0,
          length: 0,
        },
        metal: {
          Wt: 0,
          Pcs: 0,
          Rate: 0,
          Amount: 0,
          FineWt: 0,
          length: 0,
        },
        finding: {
          Wt: 0,
          Pcs: 0,
          Rate: 0,
          Amount: 0,
          FineWt: 0,
          length: 0,
        },
        misc: {
          Wt: 0,
          Pcs: 0,
          Rate: 0,
          Amount: 0,
          FineWt: 0,
          length: 0,
        },
        stone_misc: {
          Wt: 0,
          Pcs: 0,
          Rate: 0,
          Amount: 0,
          FineWt: 0,
        },
        Making_Amount_Other_Charges:0,
        fineWtByMetalWtCalculation:0,
        otherChargesMiscHallStamp:0,
      };

      let other_details = otherAmountDetail(j1?.OtherAmtDetail);
      maintotal.total_labour.labour_rate += j1?.MaKingCharge_Unit;
      maintotal.total_labour.labour_amount += j1?.MakingAmount;
      maintotal.total_other += j1?.OtherCharges;
      jobwise_totals.Making_Amount_Other_Charges += j1?.MakingAmount + j1?.OtherCharges;
      maintotal.total_Making_Amount_Other_Charges += j1?.MakingAmount + j1?.OtherCharges;
      maintotal.netwt += j1?.NetWt;
      maintotal.netwtWithLossWt =
       maintotal.netwtWithLossWt + (+j1?.NetWt + +j1?.LossWt);
      maintotal.lossWt += j1?.LossWt;
      maintotal.grosswt += j1?.grosswt;
      maintotal.total_amount += j1?.TotalAmount;
      maintotal.total_unitcost += j1?.UnitCost;
      maintotal.total_discount_amount += j1?.DiscountAmt;
      maintotal.total_purenetwt += j1?.PureNetWt;
      maintotal.total_Quantity += j1?.Quantity;
      maintotal.total_Making_Amount += j1?.MakingAmount;
      maintotal.MetalAmount += j1?.MetalAmount;
      maintotal.total_discount += j1?.Discount;
      maintotal.total_diamondHandling += j1?.TotalDiamondHandling;
      maintotal.total_Wastage += j1?.Wastage;
      maintotal.convertednetwt += j1?.convertednetwt;
      maintotal.total_csamount += j1?.CsAmount;
      maintotal.total_fineWtByMetalWtCalculation += ((j1?.NetWt * j1?.Tunch)/100);
      maintotal.totalMiscAmount += j1?.MiscAmount;
      maintotal.total_TotalCsSetcost += j1?.TotalCsSetcost;
      maintotal.total_TotalDiaSetcost += j1?.TotalDiaSetcost;
      
      //json2
      json2?.length > 0 &&
        json2?.forEach((j2, i) => {
          if (j1?.SrJobno === j2?.StockBarcode) {
            //for diamond
            if (j2?.MasterManagement_DiamondStoneTypeid === 1) {
              diamond_colorstone_misc?.push(j2);
              diamondList.push(j2);
              jobwise_totals.diamonds.Wt += j2?.Wt;
              jobwise_totals.diamonds.Pcs += j2?.Pcs;
              jobwise_totals.diamonds.Rate += j2?.Rate;
              jobwise_totals.diamonds.Amount += j2?.Amount;
              jobwise_totals.diamonds.FineWt += j2?.FineWt;
              jobwise_totals.diamonds.SettingAmount += j2?.SettingAmount;
              jobwise_totals.diamonds.length += 1;
              maintotal.diamonds.Wt += j2?.Wt;
              maintotal.diamonds.total_FineWt += j2?.FineWt;
              maintotal.diamonds.Pcs += j2?.Pcs;
              maintotal.diamonds.Rate += j2?.Rate;
              maintotal.diamonds.Amount += j2?.Amount;
              maintotal.diamonds.SettingAmount += +j2?.SettingAmount;
            }
            //for colorstone
            if (j2?.MasterManagement_DiamondStoneTypeid === 2) {
              colorstoneList.push(j2);
              diamond_colorstone_misc?.push(j2);
              jobwise_totals.colorstone.Wt += j2?.Wt;
              jobwise_totals.colorstone.Pcs += j2?.Pcs;
              jobwise_totals.colorstone.Rate += j2?.Rate;
              jobwise_totals.colorstone.Amount += j2?.Amount;
              jobwise_totals.colorstone.FineWt += j2?.FineWt;
              jobwise_totals.colorstone.SettingAmount += j2?.SettingAmount;
              jobwise_totals.colorstone.length += 1;
              maintotal.colorstone.Wt += j2?.Wt;
              maintotal.colorstone.total_FineWt += j2?.FineWt;
              maintotal.colorstone.Pcs += j2?.Pcs;
              maintotal.colorstone.Rate += j2?.Rate;
              maintotal.colorstone.Amount += j2?.Amount;
              maintotal.colorstone.SettingAmount += +j2?.SettingAmount;
            }
            //for misc
            if (j2?.MasterManagement_DiamondStoneTypeid === 4) {
              metalList.push(j2);
              jobwise_totals.metal.Wt += j2?.Wt;
              jobwise_totals.metal.Pcs += j2?.Pcs;
              jobwise_totals.metal.Rate += j2?.Rate;
              jobwise_totals.metal.Amount += j2?.Amount;
              jobwise_totals.metal.FineWt += j2?.FineWt;
              jobwise_totals.metal.length += 1;
              maintotal.metal.Wt += j2?.Wt;
              maintotal.metal.total_FineWt += +j2?.FineWt;
              maintotal.metal.FineWt += +j2?.FineWt;
              maintotal.metal.Pcs += j2?.Pcs;
              maintotal.metal.Rate += j2?.Rate;
              maintotal.metal.Amount += j2?.Amount;
            }
            //for metal
            if (j2?.MasterManagement_DiamondStoneTypeid === 3) {
              if(j2?.ShapeName === "Hallmark" || j2?.ShapeName === "Stamping"){
              }else{
                diamond_colorstone_misc?.push(j2);
              }
              miscList.push(j2);
              jobwise_totals.misc.Wt += j2?.Wt;
              jobwise_totals.misc.Pcs += j2?.Pcs;
              jobwise_totals.misc.Rate += j2?.Rate;
              jobwise_totals.misc.Amount += j2?.Amount;
              jobwise_totals.misc.FineWt += j2?.FineWt;
              jobwise_totals.misc.length += 1;
              maintotal.misc.Wt += j2?.Wt;
              maintotal.misc.total_FineWt += +j2?.FineWt;
              maintotal.misc.Pcs += j2?.Pcs;
              maintotal.misc.Rate += j2?.Rate;
              maintotal.misc.Amount += j2?.Amount;
              if(j2?.ShapeName === 'Hallmark' || j2?.ShapeName === 'Stamping' || j2?.ShapeName?.includes('Certification')){
                jobwise_totals.otherChargesMiscHallStamp += j2?.Amount;
                maintotal.total_otherChargesMiscHallStamp += j2?.Amount;
              }

            }
            //for finding
            if (j2?.MasterManagement_DiamondStoneTypeid === 5) {
              findingList.push(j2);
              jobwise_totals.finding.Wt += j2?.Wt;
              jobwise_totals.finding.Pcs += j2?.Pcs;
              jobwise_totals.finding.Rate += j2?.Rate;
              jobwise_totals.finding.Amount += j2?.Amount;
              jobwise_totals.finding.FineWt += j2?.FineWt;
              jobwise_totals.finding.length += 1;
              maintotal.finding.Wt += j2?.Wt;
              maintotal.finding.total_FineWt += +j2?.FineWt;
              maintotal.finding.Pcs += j2?.Pcs;
              maintotal.finding.Rate += j2?.Rate;
              maintotal.finding.Amount += j2?.Amount;
            }
            //for stone and misc
            if (
              j2?.MasterManagement_DiamondStoneTypeid === 2 ||
              j2?.MasterManagement_DiamondStoneTypeid === 3
            ) {
              stone_miscList.push(j2);
              jobwise_totals.stone_misc.Wt += j2?.Wt;
              jobwise_totals.stone_misc.Pcs += j2?.Pcs;
              jobwise_totals.stone_misc.Rate += j2?.Rate;
              jobwise_totals.stone_misc.Amount += j2?.Amount;
              maintotal.stone_misc.Wt += j2?.Wt;
              maintotal.stone_misc.total_FineWt += +j2?.FineWt;
              maintotal.stone_misc.Pcs += j2?.Pcs;
              maintotal.stone_misc.Rate += j2?.Rate;
              maintotal.stone_misc.Amount += j2?.Amount;
            }

            jobwise_totals.fineWtByMetalWtCalculation = ((j1?.NetWt * j1?.Tunch)/100);

            // jobwise_totals.otherChargesMiscHallStamp += (j2)

            //ending of comparing of job no block
          }
        });

      diamond_colorstone_misc?.forEach((e) => {
        maintotal.total_diamond_colorstone_misc_amount += +e?.Amount;
      });

      let obj = { ...j1 };
      
      diamond_colorstone_misc?.forEach((e) => {  
        if(e?.ShapeName === "Certification_NM award"){
            jobnodup.push(e);
        }
      })
      let diawtdup = 0;
      diamond_colorstone_misc?.forEach((e) => {
        jobnodup?.forEach((a) => {
          if((a?.StockBarcode === e?.StockBarcode) && e?.MasterManagement_DiamondStoneTypeid === 1){
              diawtdup += e?.Wt;
          }
        })
      })
      obj.diamond_colorstone_misc = diamond_colorstone_misc;
      obj.certificateWtDia = diawtdup;
      obj.diamonds = diamondList;
      obj.colorstone = colorstoneList;
      obj.misc = miscList;
      obj.metal = metalList;
      obj.finding = findingList;
      obj.totals = jobwise_totals;
      obj.grouping_of_diamonds_sqc_jobwise = blankArrDiamond;
      obj.grouping_of_colorstone_sqc_jobwise = blankArrColorstone;
      obj.grouping_of_misc_sqc_jobwise = blankArrMisc;
      // obj.grouping_of_metal_sqc_jobwise = blankArrMetal;
      obj.grouping_of_finding_sqc_jobwise = blankArrFinding;
      obj.grouping_of_stone_misc_sqc_jobwise = blankArrstone_misc;
      obj.diamondSettingGroup = diamondSettingGroup;
      obj.colorstoneSettingGroup = colorstoneSettingGroup;
      obj.diamondMetalPurityWise = diamondMetalPurityWise;
      obj.colorstoneMetalPurityWise = colorstoneMetalPurityWise;
      obj.diamondWtMetalPurityWise = diamondWtMetalPurityWise;
      obj.colorstoneWtMetalPurityWise = colorstoneWtMetalPurityWise;
      obj.Making_Amount_Other_Charges = jobwise_totals.Making_Amount_Other_Charges;
      obj.other_details = other_details;
      obj.fineWtByMetalWtCalculation = jobwise_totals.fineWtByMetalWtCalculation;
      resultArray.push(obj);
    });

  //totalAmount
  // let totalAmount = maintotal.total_amount + header?.AddLess + maintotal?.total_discount_amount ;
  // let totalAmount = maintotal.total_amount + header?.AddLess + header?.FreightCharges;
  let totalAmount = maintotal.total_amount;
  let allTax = taxGenrator(header, totalAmount);

  let brArr = [];
  if (header?.Brokerage?.length > 0) {
    let blankArr = header?.Brokerage?.split("@-@");
    let resultArr = [];
    blankArr.forEach((e, i) => {
      let obj = {};
      let arr = e?.split("#-#");
      obj.label = arr[0];
      obj.value = arr[1];
      resultArr.push(obj);
    });
    brArr = resultArr;

  }
  
  //alltax
  allTax?.length > 0 &&
  allTax?.forEach((e) => {
    const [dollars, cents] = e?.amount?.split(".");
    const dollarsInWords = numberToWords.toWords(parseInt(dollars));
    const centsInWords = cents
      ? numberToWords.toWords(parseInt(cents.padEnd(2, '0')))
      : "Zero";
    const amountInWords = [
      dollarsInWords.charAt(0).toUpperCase() + dollarsInWords.slice(1),
      "point",
      centsInWords.charAt(0).toUpperCase() + centsInWords.slice(1),
    ]
      .filter(Boolean)
      .join(" ");
      let amtInWords = CapitalizeWords(amountInWords)
    e.amountInWords = `TOTAL ${e.name} IN WORDS: ${amtInWords}`;
  });
  allTax?.forEach((e) => {
      totalAmount += (+e?.amount);
  })
  totalAmount = (+totalAmount)?.toFixed(2);
  totalAmount = (+totalAmount) + (+header?.AddLess);
  // totalAmount = (+totalAmount) + (+header?.AddLess) + (+header?.FreightCharges);

  let headerObj = {...header};

  headerObj.BrokerageDetails = brArr; 

  const finalObject = {
    resultArray: resultArray,
    mainTotal: maintotal,
    finalAmount: +totalAmount,
    allTaxes: allTax,
    header: headerObj,
    json1: json1,
    json2: json2,
  };
  return finalObject;
};
